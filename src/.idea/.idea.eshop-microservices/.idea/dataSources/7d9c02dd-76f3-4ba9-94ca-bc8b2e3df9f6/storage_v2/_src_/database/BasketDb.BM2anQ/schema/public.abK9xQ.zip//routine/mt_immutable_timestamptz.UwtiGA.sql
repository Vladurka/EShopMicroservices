create function mt_immutable_timestamptz(value text) returns timestamp with time zone
    immutable
    language sql
as
$$
select value::timestamptz

$$;

alter function mt_immutable_timestamptz(text) owner to postgres;

