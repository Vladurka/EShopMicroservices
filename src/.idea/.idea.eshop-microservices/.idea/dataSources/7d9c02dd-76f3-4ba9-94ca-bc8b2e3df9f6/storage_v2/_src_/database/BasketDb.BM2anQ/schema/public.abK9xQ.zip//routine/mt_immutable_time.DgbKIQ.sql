create function mt_immutable_time(value text) returns time without time zone
    immutable
    language sql
as
$$
select value::time

$$;

alter function mt_immutable_time(text) owner to postgres;

