create function mt_insert_shoppingcart(doc jsonb, docdotnettype character varying, docid character varying, docversion uuid) returns uuid
    language plpgsql
as
$$
BEGIN
INSERT INTO public.mt_doc_shoppingcart ("data", "mt_dotnet_type", "id", "mt_version", mt_last_modified) VALUES (doc, docDotNetType, docId, docVersion, transaction_timestamp());

  RETURN docVersion;
END;
$$;

alter function mt_insert_shoppingcart(jsonb, varchar, varchar, uuid) owner to postgres;

