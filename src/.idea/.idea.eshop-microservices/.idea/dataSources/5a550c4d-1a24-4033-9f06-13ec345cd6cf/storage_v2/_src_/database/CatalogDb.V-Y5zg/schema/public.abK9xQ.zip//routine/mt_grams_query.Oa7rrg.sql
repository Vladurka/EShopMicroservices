create function mt_grams_query(text) returns tsquery
    immutable
    strict
    language plpgsql
as
$$
BEGIN
RETURN (SELECT array_to_string(public.mt_grams_array($1), ' & ') ::tsquery);
END
$$;

alter function mt_grams_query(text) owner to postgres;

