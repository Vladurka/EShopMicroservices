create function mt_immutable_timestamp(value text) returns timestamp without time zone
    immutable
    language sql
as
$$
select value::timestamp

$$;

alter function mt_immutable_timestamp(text) owner to postgres;

